Use [pubs]

-- 6. Show the sql to find all the titles with more than one author.

SELECT t.title_id, t.title, COUNT(au.au_id) AS 'Number Of Authors'
FROM [dbo].[titles] as t
INNER JOIN [dbo].[titleauthor] AS ta
ON t.title_id = ta.title_id
INNER JOIN [dbo].[authors] AS au
ON ta.au_id = au.au_id
GROUP BY t.title_id, t.title
HAVING COUNT(t.title_id) > 1

-- 7. Show the sql to show all the authors with more than one book

SELECT au.au_id, CONCAT(au_fname,' ', au.au_lname) AS author_name, COUNT(t.title_id) AS 'Number Of Books'
FROM [dbo].[authors] as au
INNER JOIN [dbo].[titleauthor] AS ta
ON au.au_id = ta.au_id
INNER JOIN [dbo].[titles] AS t
ON ta.title_id = t.title_id
GROUP BY au.au_id, au_fname, au.au_lname
HAVING COUNT(au.au_id) > 1

-- 8. Show the sql to show the publishers with no titles

SELECT p.pub_id, p.pub_name 
FROM [dbo].[publishers] AS p
LEFT JOIN [dbo].titles AS t
ON p.pub_id = t.pub_id
WHERE p.pub_id NOT IN (SELECT ti.pub_id 
						FROM [dbo].[titles] AS ti
						INNER JOIN [dbo].[publishers] AS pu
						ON ti.pub_id = pu.pub_id)
